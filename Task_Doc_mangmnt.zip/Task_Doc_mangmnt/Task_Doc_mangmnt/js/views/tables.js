$(function(){
	$('.datatable').DataTable();
});
